#include "mpi.h"
#include <stdlib.h>
#include <stdio.h>

#define N 4

int main(int argc, char **argv)
{
    int rank, nprocs;
    MPI_File fh;
    MPI_Status status;
    MPI_Init(&argc, &argv);
    MPI_Comm_size(MPI_COMM_WORLD, &nprocs);

    if(nprocs != N)
    {
        printf("This application is meant to be run with %d processes.\n", N);
        MPI_Abort(MPI_COMM_WORLD, EXIT_FAILURE);
    }   

    MPI_Comm_rank(MPI_COMM_WORLD, &rank);


    if (rank == 0)
    {

        MPI_File_open(MPI_COMM_SELF, "filename", MPI_MODE_RDONLY, MPI_INFO_NULL, &fh);
        
        int mat[N][N];
        MPI_File_read(fh, mat, N * N, MPI_INT, &status);

        printf("Matrica pročitana iz fajla:\n");
        for (int i = 0; i < N; i++)
        {
            for (int j = 0; j < N; j++)
            {
                printf("%3d ", mat[i][j]);
            }
            printf("\n");
        }

        MPI_File_close(&fh);
    }

    MPI_Finalize();

    return 0;
}