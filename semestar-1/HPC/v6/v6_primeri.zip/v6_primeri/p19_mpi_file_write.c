#include "mpi.h"
#include <stdlib.h>
#include <stdio.h>

#define FILESIZE (20 * 4)


int main(int argc, char **argv)
{
    int *buf, rank, nprocs, nints, bufsize;
    MPI_File fh;
    MPI_Status status;
    MPI_Init(&argc, &argv);
    MPI_Comm_size(MPI_COMM_WORLD, &nprocs);

    if(nprocs != 4)
    {
        printf("This application is meant to be run with 4 processes.\n");
        MPI_Abort(MPI_COMM_WORLD, EXIT_FAILURE);
    }   

    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    
    bufsize = FILESIZE / nprocs;
    buf = (int *)malloc(bufsize);
    nints = bufsize / sizeof(int);

    for (int i = 0; i < nints; i++) {
        buf[i] = i + rank;
    }

    MPI_File_open(MPI_COMM_WORLD, "filename", MPI_MODE_CREATE | MPI_MODE_WRONLY, MPI_INFO_NULL, &fh);
    MPI_File_seek(fh, rank * bufsize, MPI_SEEK_SET);

    // Skloniti komentar sa linije ispod za demonstraciju nedefinisanog upisa
    // MPI_File_seek(fh, 0, MPI_SEEK_SET); 
    
    MPI_File_write(fh, buf, nints, MPI_INT, &status);
    MPI_File_close(&fh);
    MPI_Finalize();

    free(buf);

    return 0;
}