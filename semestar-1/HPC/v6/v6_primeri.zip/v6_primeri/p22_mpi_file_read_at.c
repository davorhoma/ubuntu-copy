#include "mpi.h"
#include <stdio.h>
#include <stdlib.h>

#define FILESIZE (20 * 4)

int main(int argc, char **argv)
{
    int *buf, rank, nprocs, nints, bufsize;
    MPI_File fh;
    MPI_Status status;
    MPI_Init(&argc, &argv);
    MPI_Comm_size(MPI_COMM_WORLD, &nprocs);

    if(nprocs != 4)
    {
        printf("This application is meant to be run with 4 processes.\n");
        MPI_Abort(MPI_COMM_WORLD, EXIT_FAILURE);
    }   

    MPI_Comm_rank(MPI_COMM_WORLD, &rank);

    bufsize = FILESIZE / nprocs;
    buf = (int *)malloc(bufsize);
    nints = bufsize / sizeof(int);
    MPI_File_open(MPI_COMM_WORLD, "filename", MPI_MODE_RDONLY, MPI_INFO_NULL, &fh);
    MPI_File_read_at(fh, rank * bufsize, buf, nints, MPI_INT, &status);

    MPI_File_close(&fh);

    /**
     * Sinhronizacija radi izbegavanja isprepletanog ispisa elemenata.
    */
    for (int i = 0; i < nprocs; i++) {
        if (i == rank) {
            printf("Process %d array: ", rank);
            for (int j = 0; j < nints; j++) {
                printf("%d ", buf[j]);
            }
            printf("\n");
        }
        MPI_Barrier(MPI_COMM_WORLD);
    }
    
    MPI_Finalize();

    free(buf);

    return 0;
}