#include "mpi.h"
#include <stdlib.h>
#include <stdio.h>

#define N 4

int main(int argc, char **argv)
{
    int rank, nprocs;
    MPI_File fh;
    MPI_Status status;
    MPI_Init(&argc, &argv);
    MPI_Comm_size(MPI_COMM_WORLD, &nprocs);

    if(nprocs != N)
    {
        printf("This application is meant to be run with %d processes.\n", N);
        MPI_Abort(MPI_COMM_WORLD, EXIT_FAILURE);
    }   

    MPI_Comm_rank(MPI_COMM_WORLD, &rank);

    int mat_col[N];

    for (int i = 0; i < N; i++)
    {
        mat_col[i] = rank + i * N;
    }

    MPI_Datatype vector_type;
    MPI_Type_vector(N, 1, N, MPI_INT, &vector_type);
    MPI_Type_commit(&vector_type);


    MPI_File_open(MPI_COMM_WORLD, "filename", MPI_MODE_CREATE | MPI_MODE_WRONLY, MPI_INFO_NULL, &fh);
    MPI_File_set_view(fh, rank * sizeof(int), MPI_INT, vector_type, "native", MPI_INFO_NULL);
    MPI_File_write(fh, mat_col, N, MPI_INT, &status);
    MPI_File_close(&fh);
    MPI_Finalize();


    return 0;
}