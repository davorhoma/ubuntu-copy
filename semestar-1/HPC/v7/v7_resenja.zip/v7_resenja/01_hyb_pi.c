#include <stdio.h>
#include <mpi.h>
#include <omp.h>


static long num_steps = 100000000;

int main(int argc, char* argv[]) {

    int provided;
    MPI_Init_thread(&argc, &argv, MPI_THREAD_MULTIPLE, &provided);
    
    int rank, size;

    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &size);

    double step = 1.0 / (double) num_steps;

    int steps_per_process = num_steps / size;

    int my_start = rank * steps_per_process;
    int my_end = my_start + steps_per_process;

    double x, my_sum = 0.0;
    
    #pragma omp parallel private(x) reduction(+ : my_sum)
    {
        #pragma omp single
        {
            printf("Process %d: num threads: %d\n", rank, omp_get_num_threads());
        }

        #pragma omp for
        for (int i = my_start; i < my_end; i++) {
            x = (i + 0.5) * step;
            my_sum = my_sum + 4.0 / (1.0 + x * x);
        }
    }

    double sum, pi;
    MPI_Reduce(&my_sum, &sum, 1, MPI_DOUBLE, MPI_SUM, 0, MPI_COMM_WORLD);

    if (rank == 0) {
        pi = sum * step;
        printf("Pi = %lf\n", pi);
    }

    MPI_Finalize();

}
