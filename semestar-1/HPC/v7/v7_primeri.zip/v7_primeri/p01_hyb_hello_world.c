#include "mpi.h"
#include <omp.h>
#include <stdio.h>

int main(int argc, char* argv[]) {

    MPI_Init(&argc, &argv);

    int rank;
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);

    #pragma omp parallel
    {
        printf("Hello world from thread %d of process %d!\n", omp_get_thread_num(), rank);
    }
    
    MPI_Finalize();
}