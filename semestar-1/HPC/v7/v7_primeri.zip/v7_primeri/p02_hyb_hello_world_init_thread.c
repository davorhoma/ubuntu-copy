#include "mpi.h"
#include <omp.h>
#include <stdio.h>

int main(int argc, char* argv[]) {

    int provided_interoperability;
    MPI_Init_thread(&argc, &argv, MPI_THREAD_SINGLE, &provided_interoperability);

    printf("Oper: %d\n", provided_interoperability);

    int rank;
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);


    /**
     * Bez obzira na traženu interoperabilnost, postoji šansa da će se
     * paralelni region izvršiti kao da je u pitanju MPI_THREAD_MULTIPLE
    */
    #pragma omp parallel 
    {
        printf("Hello world from thread %d of process %d!\n", omp_get_thread_num(), rank);
    }
    
    MPI_Finalize();
}