import os

# Get the greeting message from the environment variable
greeting = os.getenv("GREETING")
print(greeting)
